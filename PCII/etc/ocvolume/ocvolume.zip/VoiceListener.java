package com.gampire.pc.speech;

import org.oc.ocvolume.OCVolume;
import org.oc.ocvolume.audio.MicInput;

public class VoiceListener {

    public interface RecognizedWordActionListener {
        /**
         * Invoked when a word has been recognized
         */
        public void performAction(String recognizedWord);
    }

    private OCVolume engine = new OCVolume("resources/dict", "resources/");
    private MicInput mic;
    private WaitForRecognizedWordThread waiter;
    private RecognizedWordActionListener listener;
    
    public VoiceListener(RecognizedWordActionListener listener) {
        this.listener = listener;
    }
        
    public void start() {
        mic = new MicInput();
        mic.start();
        waiter = new WaitForRecognizedWordThread();
        waiter.start();
    }

    @SuppressWarnings("deprecation")
    public void stop() {
        mic.stopRecord();
        waiter.stop();
    }

    private class WaitForRecognizedWordThread extends Thread {

        public void run() {
            mic.removeOldWord();

            while (!mic.byteArrayComplete()) {
                try {
                    Thread.sleep(200);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            mic.newWord();

            short recordedSample[] = mic.returnShortArray();

            String recognizedWord = engine.getWord(recordedSample);

            listener.performAction(recognizedWord);
        }
    }
}
